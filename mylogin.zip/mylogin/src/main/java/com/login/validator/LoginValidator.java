package com.login.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.login.command.Login;

public class LoginValidator implements Validator {

	public boolean supports(Class clazz) {
		// just validate the Customer instances
		return Login.class.isAssignableFrom(clazz);

	}

	public void validate(Object target, Errors errors) {

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username",
				"required.userName", "Field name is required.");
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password",
				"required.password", "Field name is required.");

		Login login = (Login) target;

		
	

		
	}

}