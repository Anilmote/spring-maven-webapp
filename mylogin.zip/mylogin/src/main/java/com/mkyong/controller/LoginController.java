package com.mkyong.controller;

import com.login.command.Login;
import com.login.validator.LoginValidator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.support.SessionStatus;

@Controller
public class LoginController {

	LoginValidator loginValidator;

	@Autowired
	public LoginController(LoginValidator loginValidator) {
		this.loginValidator = loginValidator;
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String initForm(ModelMap model) {
		System.out.println("*** login initial request");

		Login login = new Login();

		// command object
		model.addAttribute("login", login);

		// return form view
		return "login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String processSubmit(@ModelAttribute("login") Login login, BindingResult result, SessionStatus status) {

		loginValidator.validate(login, result);

		if (result.hasErrors()) {
			// if validator failed
			return "login";
		} else {
			status.setComplete();
			// form success
			return "loginSuccess";
		}
	}

}